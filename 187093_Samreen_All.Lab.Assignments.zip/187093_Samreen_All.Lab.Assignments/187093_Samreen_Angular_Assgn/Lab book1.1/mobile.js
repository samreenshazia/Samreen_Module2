"use strict";
exports.__esModule = true;
var Mobile = /** @class */ (function () {
    function Mobile(id, name, cost) {
        this.mobileId = id;
        this.mobileName = name;
        this.mobileCost = cost;
    }
    Mobile.prototype.printMobileDetails = function () {
        console.log("\n");
        console.log("Mobile ID: " + this.mobileId +
            "\nMobile Name: " + this.mobileName +
            "\nMobile Cost: " + this.mobileCost);
    };
    return Mobile;
}());
exports.Mobile = Mobile;
